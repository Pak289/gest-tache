<?php
    include_once ('obj/stm_Client.php');
    include_once ('obj/stm_Task.php');
    include_once ('core/stm_Router.php');
    include_once ('core.php');
