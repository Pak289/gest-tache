<footer class="footer fx-center background">
    0.1.0 - Crous Strasbourg © 2020
</footer>