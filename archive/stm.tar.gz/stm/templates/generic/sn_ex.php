<?php $activePage = basename($_SERVER['PHP_SELF'], ".php"); ?>



<?php unset($activePage); ?>