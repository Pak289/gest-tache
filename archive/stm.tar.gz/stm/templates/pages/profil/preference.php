<?php include_once('../base.php'); ?>

<body class="layout" style="background: #EAEAEA;">
<?php include_once('../elements/header.php'); ?>

<div id="contenu"></div>

<?php include('../elements/footer.php'); ?>
</body>