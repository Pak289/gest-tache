<?php
session_start();
include_once('../../config/basic.php');

$database = connection();

$stmt = $database->prepare("UPDATE UG SET name = :name, abreviation = :abv  WHERE id = :id");
$stmt->execute(array(
    ':name' => $_POST['name'],
    ':abv' => $_POST['abv'],
    ':id' => $_POST['groupId']
));

header('Location: ' . stm_Router::$URL . stm_Router::$TEMPLATES . 'pages/gestion/ug.php');
exit();
