<?php
include_once('config/basic.php');
session_start();

$user = unserialize($_SESSION['user']);
var_dump($user);
echo $user->getGroup()->getCanWriteCommentary();
